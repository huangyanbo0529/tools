#include "FreeRTOS.h"
#include "semphr.h"
#include "cmsis_os2.h"  
#include "task.h"
#include <stdio.h>
#include "stm32f1xx_hal.h"

//SemaphoreHandle_t semaphoreBinary;
SemaphoreHandle_t semaphoreMutex;

static void taskAFunction(void *arg)
{
		BaseType_t ret;
		
		osDelay(2000);
		
		printf("TaskA running\r\n");

#if 0
		ret = xSemaphoreTake(semaphoreBinary,portMAX_DELAY);
		if(ret != pdTRUE){
				printf("Fail to xSemaphoreTake\r\n");
				return;
		}
#endif 
		ret = xSemaphoreTake(semaphoreMutex,portMAX_DELAY);
		if(ret != pdTRUE){
				printf("Fail to xSemaphoreTake\r\n");
				return;
		}
		
		printf("TaskA print\r\n");
		
#if 0
		ret = xSemaphoreGive(semaphoreBinary);
	  if(ret != pdTRUE){
			  printf("Fail to xSemaphoreTake\r\n");
			  return;
		}
#endif 
		ret = xSemaphoreGive(semaphoreMutex);
	  if(ret != pdTRUE){
			  printf("Fail to xSemaphoreTake\r\n");
			  return;
		}		
		
		vTaskDelete(NULL);
}

static void taskBFunction(void *arg)
{
		int i;
	  BaseType_t ret;
	  printf("TaskB running\r\n");
		
#if 0
	  ret = xSemaphoreTake(semaphoreBinary,portMAX_DELAY);
	  if(ret != pdTRUE){
			  printf("Fail to xSemaphoreTake\r\n");
			  return;
		}
#endif 
		ret = xSemaphoreTake(semaphoreMutex,portMAX_DELAY);
		if(ret != pdTRUE){
				printf("Fail to xSemaphoreTake\r\n");
				return;
		}
		
	
		printf("TaskB take semaphore\r\n");
		for(i = 0;i < 10;i ++){
				printf("TaskB print\r\n");
			  HAL_Delay(1000);
		}
		
#if 0
		ret = xSemaphoreGive(semaphoreBinary);
	  if(ret != pdTRUE){
			  printf("Fail to xSemaphoreGive\r\n");
			  return;
		}
#endif 
		ret = xSemaphoreGive(semaphoreMutex);
	  if(ret != pdTRUE){
			  printf("Fail to xSemaphoreTake\r\n");
			  return;
		}		
		
		vTaskDelete(NULL);
}

static void taskCFunction(void *arg)
{
	int i;
	
	osDelay(5000);
	printf("TaskC running\r\n");

	for(i = 0;i < 3;i ++){
			printf("TaskC print\r\n");
			HAL_Delay(1000);
	}
	
	vTaskDelete(NULL);
}

void freertos_priority_inversion_init(void)
{
	BaseType_t ret;
	TaskHandle_t taskAHandle;
	TaskHandle_t taskBHandle;
	
#if 0
	semaphoreBinary = xSemaphoreCreateBinary();
	if(!semaphoreBinary){
		 printf("Fail to xSemaphoreCreateBinary\r\n");
		 return;
	}
	
	ret = xSemaphoreGive(semaphoreBinary);
	if(ret != pdTRUE){
			 printf("Fail to xSemaphoreGive\r\n");
			 return;
	}
#endif 
	semaphoreMutex = xSemaphoreCreateMutex();
	if(!semaphoreMutex){
		 printf("Fail to xSemaphoreCreateBinary\r\n");
		 return;
	}
	
	ret = xTaskCreate(taskAFunction,"taskA",128,NULL,osPriorityNormal2,&taskAHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskA failed\r\n");
			return;
	}
	
	ret = xTaskCreate(taskBFunction,"taskB",128,NULL,osPriorityNormal,&taskBHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskB failed\r\n");
			return;
	} 
	
	ret = xTaskCreate(taskCFunction,"taskC",128,NULL,osPriorityNormal1,&taskBHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskB failed\r\n");
			return;
	} 
	
	return;
}
