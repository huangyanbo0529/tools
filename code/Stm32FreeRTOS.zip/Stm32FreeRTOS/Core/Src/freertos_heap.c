#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>

void heap_test(void)
{
	uint8_t *p;
	size_t freeHeapMemSize = xPortGetFreeHeapSize();
	printf("Free Heap Memory size:%d\r\n",freeHeapMemSize);
	
	p = pvPortMalloc(100);
	if(!p){
		 printf("Fail to pvPortMalloc\r\n");
		 return;
	}
	printf("Malloc 100byte\r\n");
	
	freeHeapMemSize = xPortGetFreeHeapSize();
	printf("Free Heap Memory size:%d\r\n",freeHeapMemSize);
	
	vPortFree(p);
	printf("Free 100byte\r\n");
	
	freeHeapMemSize = xPortGetFreeHeapSize();
	printf("Free Heap Memory size:%d\r\n",freeHeapMemSize);
	
	return;
}
