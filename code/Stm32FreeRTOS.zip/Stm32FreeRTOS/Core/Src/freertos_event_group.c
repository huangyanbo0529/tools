#include "FreeRTOS.h"
#include "event_groups.h"
#include "cmsis_os2.h"  
#include "task.h"
#include <stdio.h>

#define ATASK_PRINT_EVENT (1 << 0)
#define BTASK_PRINT_EVENT (1 << 1)

EventGroupHandle_t eventGroup;

void waitEvent(const EventBits_t   uxBitsToWaitFor)
{
	 xEventGroupWaitBits(eventGroup,uxBitsToWaitFor,pdTRUE,pdFALSE,portMAX_DELAY);
}

void setEvent(const EventBits_t   uxBitsToSet)
{
	 xEventGroupSetBits(eventGroup,uxBitsToSet);
}

static void taskAFunction(void *arg)
{
	while(1){
		 waitEvent(BTASK_PRINT_EVENT);
		 printf("TaskA print\r\n");
		 setEvent(ATASK_PRINT_EVENT);
	}
}

static void taskBFunction(void *arg)
{
		while(1){
		 waitEvent(ATASK_PRINT_EVENT);
		 printf("TaskB print\r\n");
		 setEvent(BTASK_PRINT_EVENT);
	 }
}

void freertos_eventgroup_init(void)
{
	BaseType_t ret;
	TaskHandle_t taskAHandle;
	TaskHandle_t taskBHandle;
	
	eventGroup = xEventGroupCreate();
	if(!eventGroup){
		 printf("Fail to xEventGroupCreate\r\n");
		 return;
	}
	
	setEvent(ATASK_PRINT_EVENT);
	
	ret = xTaskCreate(taskAFunction,"taskA",128,NULL,osPriorityNormal,&taskAHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskA failed\r\n");
			return;
	}
	
	ret = xTaskCreate(taskBFunction,"taskB",128,NULL,osPriorityNormal,&taskBHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskB failed\r\n");
			return;
	} 
	
	return;
}
