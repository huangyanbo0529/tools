#define configUSE_QUEUE_SETS 1

#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os2.h"  
#include "usart.h"
#include <stdio.h>

#define STACK_SIZE 128

TaskHandle_t taskHandle;
TaskHandle_t staticTaskHandle;
TaskHandle_t printTaskHandle;
StackType_t  stackBuffer[STACK_SIZE];
StaticTask_t staticTCBBuffer;

int fputc(int ch, FILE *f)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1,HAL_MAX_DELAY);
		return  EOF;
}

void taskFunction(void *arg)
{
	  int i;
		while(1){
			for(i = 0;i < 3;i ++){
				printf("runing task1\r\n");
			  osDelay(1000);
			}
			break;
			//vTaskDelete(NULL);
		}
		
		vTaskResume(staticTaskHandle);
		//vTaskDelete(staticTaskHandle);
		vTaskDelete(NULL);
}

void showTaskInfomation(void *arg)
{
		char buffer[200];
		TickType_t lastWakeTime = xTaskGetTickCount();
	
		while(1){
				vTaskList(buffer);
				printf("-----------------------------------------\r\n");
				printf("Name    State   Priority    Stack   Num\r\n");
				printf("%s\r\n",buffer);
			  //vTaskDelay(1000);
				vTaskDelayUntil(&lastWakeTime,1000);
		}
}

void taskFunctionStatic(void *arg)
{
		printf("start runing static task\r\n");
		vTaskSuspend(NULL);
		while(1){
				printf("runing static task\r\n");
			  osDelay(1000);
		}
}

void freertos_task_init(void)
{
	BaseType_t ret;
	TaskHandle_t taskHandle;
	
	ret = xTaskCreate(taskFunction,"task1",128,NULL,osPriorityNormal,&taskHandle);
	if(ret != pdPASS){
			printf("xTaskCreate task1 failed\r\n");
			return;
	}
	
	ret = xTaskCreate(showTaskInfomation,"printTask",128,NULL,osPriorityNormal,&printTaskHandle);
	if(ret != pdPASS){
			printf("xTaskCreate printTask failed\r\n");
			return;
	}
	
	staticTaskHandle = xTaskCreateStatic(taskFunctionStatic,
																 "static-task",
																 STACK_SIZE,
																 NULL,
																 osPriorityNormal,
															   stackBuffer,
																 &staticTCBBuffer);
	if(!staticTaskHandle){
		printf("Fail to xTaskCreateStatic\r\n");
		return;
	}															  
	
	return;
}
