#include "FreeRTOS.h"
#include "semphr.h"
#include "cmsis_os2.h"  
#include "task.h"
#include <stdio.h>

SemaphoreHandle_t semaphoreA;
SemaphoreHandle_t semaphoreB;

void P(SemaphoreHandle_t handle)
{
	 BaseType_t ret = xSemaphoreTake(handle,portMAX_DELAY);
	 if(ret != pdTRUE){
			 printf("Fail to xSemaphoreTake\r\n");
		   return;
	 }
}

void V(SemaphoreHandle_t handle)
{
	 BaseType_t ret = xSemaphoreGive(handle);
	 if(ret != pdTRUE){
			 printf("Fail to xSemaphoreGive\r\n");
		   return;
	 } 
}

static void taskAFunction(void *arg)
{
	//take A print resource:1
	while(1){
		 P(semaphoreA);//1--0
		 printf("TaskA print\r\n");
		 V(semaphoreB);//0--1
	}
}

static void taskBFunction(void *arg)
{
	 //take B print resource:0
		while(1){
		 P(semaphoreB);
		 printf("TaskB print\r\n");
		 V(semaphoreA);
	}
}

void freertos_semaphore_init(void)
{
	BaseType_t ret;
	TaskHandle_t taskAHandle;
	TaskHandle_t taskBHandle;
	
	semaphoreA = xSemaphoreCreateCounting(1,1);
	if(!semaphoreA){
		 printf("Fail to xSemaphoreCreateCounting\r\n");
		 return;
	}
	
	semaphoreB = xSemaphoreCreateCounting(1,0);
	if(!semaphoreB){
		 printf("Fail to xSemaphoreCreateCounting\r\n");
		 return;
	}
	
	ret = xTaskCreate(taskAFunction,"taskA",128,NULL,osPriorityNormal,&taskAHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskA failed\r\n");
			return;
	}
	
	ret = xTaskCreate(taskBFunction,"taskB",128,NULL,osPriorityNormal,&taskBHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskB failed\r\n");
			return;
	} 
	
	return;
}
