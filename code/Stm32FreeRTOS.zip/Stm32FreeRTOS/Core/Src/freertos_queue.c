#include "FreeRTOS.h"


#include "queue.h"
#include "stdio.h"
#include "task.h"
#include "cmsis_os2.h"  

#define QUEUE_LEN 10
#define DATA_MAX  20

QueueHandle_t queueAHandle;
QueueHandle_t queueBHandle;
QueueSetHandle_t queueSet;

typedef struct{
	uint32_t type;
	uint8_t  data[DATA_MAX];
}QueueItem_t;

#define osPrintf(...) do{\
		taskENTER_CRITICAL();\
	  printf(__VA_ARGS__);\
		taskEXIT_CRITICAL();\
	}while(0)

void taskAFunction(void *arg)
{
	int taskType = 0;
	QueueItem_t item;
	BaseType_t ret;
	
	while(1){
		//send message
		item.type = taskType ++;
		sprintf((char *)item.data,"A message:%d",item.type);
		
		ret = xQueueSend(queueAHandle,&item,100);
		if(ret != pdPASS){
			 printf("Fail to xQueueSend\r\n");
			 break;
		}
		
		osPrintf("TaskA send %s\r\n",(char *)item.data);
		
		vTaskDelay(1000);
	}
	
	vTaskDelete(NULL);
}

void taskBFunction(void *arg)
{
	int taskType = 0;
	QueueItem_t item;
	BaseType_t ret;
	
	while(1){
		//send message
		item.type = taskType ++;
		sprintf((char *)item.data,"B message:%d",item.type);
		
		ret = xQueueSend(queueBHandle,&item,100);
		if(ret != pdPASS){
			 printf("Fail to xQueueSend\r\n");
			 break;
		}
		
		osPrintf("TaskB send %s\r\n",(char *)item.data);
		
		vTaskDelay(1000);
	}
	
	vTaskDelete(NULL);
}

void taskCFunction(void *arg)
{
	 BaseType_t ret;
	 QueueItem_t item;
	 QueueSetMemberHandle_t queueHandle;
	
	 osPrintf("Task C running\r\n");
	
	 //recv message
	 while(1){
		  queueHandle = xQueueSelectFromSet(queueSet,portMAX_DELAY);
		  if(!queueHandle){
				 printf("Fail to xQueueSelectFromSet\r\n");
				 break;
			}
		 
			ret = xQueueReceive(queueHandle,&item,portMAX_DELAY);
		  if(ret != pdPASS){
					printf("Fail to xQueueReceive\r\n");
					break;
			}
			
			osPrintf("Task C recv %d:%s\r\n",item.type,item.data);
	 }
	 
	 vTaskDelete(NULL);
}


void freertos_queue_init(void)
{
	BaseType_t ret;
	TaskHandle_t taskAHandle;
	TaskHandle_t taskBHandle;
	TaskHandle_t taskCHandle;
	
	queueAHandle = xQueueCreate(QUEUE_LEN,sizeof(QueueItem_t));
	if(!queueAHandle){
		 printf("Fail to xQueueCreate\r\n");
		 return;
	}
	
	queueBHandle = xQueueCreate(QUEUE_LEN,sizeof(QueueItem_t));
	if(!queueBHandle){
		 printf("Fail to xQueueCreate\r\n");
		 return;
	}
	
	queueSet = xQueueCreateSet(QUEUE_LEN + QUEUE_LEN);
	if(!queueSet){
		 printf("Fail to xQueueCreateSet\r\n");
		 return;
	}
	
	ret = xQueueAddToSet(queueAHandle,queueSet);
	if(ret !=pdTRUE){
		 printf("Fail to xQueueAddToSet\r\n");
		 return;
	}
	
	ret = xQueueAddToSet(queueBHandle,queueSet);
	if(ret !=pdTRUE){
		 printf("Fail to xQueueAddToSet\r\n");
		 return;
	}
	
	
#if 1
	ret = xTaskCreate(taskAFunction,"taskA",128,NULL,osPriorityNormal,&taskAHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskA failed\r\n");
			return;
	}
#endif 
	

	ret = xTaskCreate(taskBFunction,"taskB",128,NULL,osPriorityNormal,&taskBHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskB failed\r\n");
			return;
	} 

	ret = xTaskCreate(taskCFunction,"taskC",128,NULL,osPriorityNormal,&taskCHandle);
	if(ret != pdPASS){
		  printf("xTaskCreate taskC failed,ret:%d\r\n",(int)ret);
			return;
	} 	
	
	return;
}
