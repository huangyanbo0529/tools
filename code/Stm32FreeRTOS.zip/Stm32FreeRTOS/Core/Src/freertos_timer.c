#include "FreeRTOS.h"
#include "timers.h"
#include <stdio.h>

void timerCallbackFunction( TimerHandle_t xTimer )
{
		uint32_t timerID = *(uint32_t *)pvTimerGetTimerID(xTimer);
		printf("timer ID:%d timeout\r\n",timerID);
}

void freertos_timer_init(void)
{
	BaseType_t ret;
	TimerHandle_t timerHandle;
	uint32_t timerID;
	
	timerHandle = xTimerCreate("timer1",1000,pdTRUE,&timerID,timerCallbackFunction);
	if(!timerHandle){
			printf("Fail to xTimerCreate for timer1\r\n");
			return;
	}
	
	ret = xTimerStart(timerHandle,1000);
	if(ret != pdPASS){
			printf("Fail to xTimerStart\r\n");
		  return;
	}
	
	return;
}
