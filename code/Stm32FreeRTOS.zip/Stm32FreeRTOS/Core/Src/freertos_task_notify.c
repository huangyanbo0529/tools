#include "FreeRTOS.h"
#include "event_groups.h"
#include "cmsis_os2.h"  
#include "task.h"
#include <stdio.h>

TaskHandle_t taskAHandle;
TaskHandle_t taskBHandle;

void waitNotify(void)
{
	 uint32_t value = ulTaskNotifyTake(pdTRUE,portMAX_DELAY);
	 printf("notify value:%d\r\n",value);
	 return;
}

void sendNotify(TaskHandle_t handle)
{
		xTaskNotifyGive(handle);
}

static void taskAFunction(void *arg)
{
	while(1){
		 waitNotify();
		 printf("TaskA print\r\n");
		 sendNotify(taskBHandle);
	}
}

static void taskBFunction(void *arg)
{
		while(1){
		 waitNotify();
		 printf("TaskB print\r\n");
		 sendNotify(taskAHandle);
	 }
}

void freertos_tasknotify_init(void)
{
	BaseType_t ret;

	
	
	ret = xTaskCreate(taskAFunction,"taskA",128,NULL,osPriorityNormal,&taskAHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskA failed\r\n");
			return;
	}
	
	ret = xTaskCreate(taskBFunction,"taskB",128,NULL,osPriorityNormal,&taskBHandle);
	if(ret != pdPASS){
			printf("xTaskCreate taskB failed\r\n");
			return;
	} 
	
	sendNotify(taskAHandle);
	
	return;
}
