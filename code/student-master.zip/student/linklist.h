#ifndef __LINKLIST_H__
#define __LINKLIST_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//学生信息结构体
typedef struct student
{
    int id;             //学号
    char name[20];      //姓名
    char sex[20];       //性别
    int age;            //年纪
    double score;       //分数
}s_t;

typedef s_t datatype_t; //用户自定义数据类型

typedef struct node
{
    datatype_t data;   //数据域保存有效的数据
    struct node *next;  //保存下一个结点的地址
}linknode_t;

extern linknode_t *create_empty_linklist();
extern void insert_head_linklist(linknode_t *head,datatype_t data);
extern void insert_tail_linklist(linknode_t *head,datatype_t data);
extern void insert_order_linklist(linknode_t *head,datatype_t data);
extern int is_empty_linklist(linknode_t *head);
extern int delete_data_linklist(linknode_t *head,int id);
extern void clean_up_linklist(linknode_t *head);
#endif
