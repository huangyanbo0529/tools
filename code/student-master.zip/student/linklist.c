#include "linklist.h"

//[1]创建一个新的链表,为头节点在堆区分配空间
linknode_t *create_empty_linklist()
{
        linknode_t *head = NULL;
        //1.为头节点在堆区分配空间，用指针head保存.
        
        //2.头节点的指针域为NULL。
        head = (linknode_t *)malloc(sizeof(linknode_t));
        if(NULL == head)
        {
                printf("malloc is fail!\n");
                return NULL;
        }
        
        memset(head,0,sizeof(linknode_t));
        
        head->next = NULL; //可省略
        
        return head;
}

//[2]头插法插入数据：每次都在头结点后插入我们需要的数据。
//   [特点:插入的顺序和输出的顺序是相反的。]
void insert_head_linklist(linknode_t *head,datatype_t data)
{
        //1.为新节点在堆区分配空间，用指针temp保存
        linknode_t *temp = NULL;
        temp = (linknode_t *)malloc(sizeof(linknode_t));
        //2.把data数据放到temp结点的数据域
        
        temp->data = data;
        //3.把temp结点插入到head结点后面
        temp->next = head->next;
        head->next = temp;
        return ;
}

void insert_tail_linklist(linknode_t *head,datatype_t data)
{
        //1.为新节点在堆区分配空间，用指针temp保存
        linknode_t *temp = NULL;
        temp = (linknode_t *)malloc(sizeof(linknode_t));
        //2.把data数据放到temp结点的数据域
        temp->data = data;

        //3.循环遍历找到尾结点
        linknode_t *p = head;

        while(p->next != NULL)
        {
                p = p->next;        
        }

        //4.在p后插入temp结点
        temp->next = p->next;
        p->next = temp;
        return ;
}

void insert_order_linklist(linknode_t *head,datatype_t data)
{
        //1.为新节点在堆区分配空间，用指针temp保存
        linknode_t *temp = NULL;
        temp = (linknode_t *)malloc(sizeof(linknode_t));
        //2.把data数据放到temp结点的数据域
        temp->data = data;

        linknode_t *p = head;

        while(p->next != NULL && data.score > p->next->data.score)
        {
                p = p->next;        
        }
        //在p结点后插入我们的数据data
        temp->next = p->next;
        p->next = temp;

        return ;
}

int is_empty_linklist(linknode_t *head)
{
	return head->next == NULL ? 1 : 0;
}

int delete_data_linklist(linknode_t *head,int id)
{
	linknode_t *p = NULL;
	linknode_t *q = NULL;

	int flag = 0;

	if(is_empty_linklist(head))
	{
		return -1;	
	}

	p = head;

	//没有遍历到链表尾部
	while(p->next != NULL)
	{
		if(p->next->data.id == id)	
		{
			//保存要删除结点的地址
			q = p->next;
			p->next = q->next;
			free(q);

			q = NULL;

			flag = 1;
		
		}else{
			p = p->next;	
		}
	}

	if(flag == 0)
	{
		return -2;	
	}else{
		return 0;
	}
}

//删除链表中所有的结点
void clean_up_linklist(linknode_t *head)
{
	linknode_t *p = head;
	linknode_t *q = NULL;

	while(p != NULL)
	{
		q = p->next;
		//printf_data_linklist(p);
		free(p);
		p = q;
	}
	return ;
}
