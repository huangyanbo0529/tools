#include "student_manager.h"

bool login_status = false;

//这里设置默认初始账户和密码:,root
void login_in()
{
	char username[30] = {0};
	char password[30] = {0};
	
    //都为NULL说明为登录状态
	printf("=========== 登录 ============\n");
	printf("账户: ");
	//gets(username);
	fgets(username,sizeof(username),stdin);
	username[strlen(username) - 1] = '\0';
	printf("密码: ");
	//gets(password);
	fgets(password,sizeof(password),stdin);
	password[strlen(password) - 1] = '\0';

	if((strcmp(username,"root") == 0) && (strcmp(password,"root") == 0))
	{
		login_status = true;
		printf("登录成功!\n");
	}
	else
	{
		login_status = false;
		printf("密码错误!\n");
	}

    //扩展：后期学习了文件操作后,
    //可以创建一个user.csv文件。把账户和密码存放到
    //csv文件中。用户输入后，与user.csv文件中的
    //账户和密码进行比对。
    //情况1：密码正确，进入下一个业面
    //情况2：密码错误 ,新用户——提示注册
    //                老用户——重新输入
    return ;
}


void insert_student(linknode_t *head)
{
	s_t  st = {0};
	linknode_t *p = NULL;
	bool is_id_exist = true;

	//1.输入学生的信息
	printf("------------------------------------------------\n");
	printf("请输入学生的信息[学号 姓名 性别 年龄 分数] : ");
	scanf("%d%s%s%d%lf",&(st.id),st.name,st.sex,&(st.age),&(st.score));
	while(getchar() != '\n'); //清除缓存信息
	
	//2.遍历链表，以id作为基准，判断学生是否存在
	p = head;
	while(p->next != NULL)
	{
		//若是学生存在
		if(p->next->data.id == st.id)
		{
			is_id_exist = false;	
			printf("已经存在id = %d号学生,请重新输入!\n",st.id);	
			break;
		}
		p = p->next;	
	}

	if(is_id_exist == true)
	{
		insert_tail_linklist(head,st);
		printf("插入成功!\n");
	}
	return ;
}

void display_student(linknode_t *head)
{
	linknode_t *p = head;

	printf("===========================学生信息表==========================\n");
	printf("---------------------------------------------------------------\n");
	printf("|学号\t| 姓名\t| 性别\t| 年龄\t| 分数\t|\n");
	while(p->next != NULL)
	{
		printf("|%d\t| %s\t| %s\t| %d\t| %.1f\t|\n",p->next->data.id, \
				p->next->data.name,p->next->data.sex,p->next->data.age,p->next->data.score);
		p = p->next;
	}
	printf("---------------------------------------------------------------\n");
	return ;
}

void find_student(linknode_t *head)
{
	linknode_t *p = head;
	int id;
	printf("请输入要查找学生编号 : ");
	scanf("%d",&id);

	while(p->next != NULL)
	{
		if(p->next->data.id == id)
		{
			printf("---------------------------------------------------------------\n");
			printf("|学号\t| 姓名\t| 性别\t| 年龄\t| 分数\t|\n");
			printf("|%d\t| %s\t| %s\t| %d\t| %.1f\t|\n",p->next->data.id, \
				p->next->data.name,p->next->data.sex,p->next->data.age,p->next->data.score);
			printf("---------------------------------------------------------------\n");
			return ;
		}

		p = p->next;	
	}

	if(p->next == NULL)
	{
		printf("---------------------------------------------------------------\n");
		printf("编号输入错误!\n");	
		printf("---------------------------------------------------------------\n");
	}

	return ;
}

void display_update_info()
{
	printf(" ┏━━━━━━━━━━━━━━━━━━━━━━━┓ \n");
	printf(" ┃        学生信息       ┃ \n");
	printf(" ┣━━━━━━━━━━━━━━━━━━━━━━━┫ \n");
	printf(" ┃      1. 修改学号      ┃ \n");
	printf(" ┃      2. 修改姓名      ┃ \n");
	printf(" ┃      3. 修改性别      ┃ \n");
	printf(" ┃      4. 修改年龄      ┃ \n");
	printf(" ┃      5. 修改分数      ┃ \n");
	printf(" ┃      6. 退出          ┃ \n");
	printf(" ┗━━━━━━━━━━━━━━━━━━━━━━━┛\n");
	return ;
}

void user_change_data(linknode_t *temp,int id)
{
	char user_data[100] = {0};
	int new_id;
	int new_age;
	double new_score;
	printf("请输入需要修改新的数据 : ");
	scanf("%s",user_data);

	switch(id)
	{
	case 1:
		new_id = atoi(user_data);
		if(new_id > 0)
		{
			temp->data.id = new_id;	
		}
		break;
	case 2:
		memset(temp->data.name,0,20);
		strcpy(temp->data.name,user_data);
		break;
	case 3:
		memset(temp->data.sex,0,20);
		strcpy(temp->data.sex,user_data);
		break;
	case 4:
		new_age = atoi(user_data);
		if(new_age > 0)
		{
			temp->data.age = new_age;	
		}
		break;
	case 5:
		new_score = atof(user_data);
		if(new_age > 0)
		{
			temp->data.score = new_score;	
		}
		break;
	case 6:
		printf("退出!\n");
		return ;
	}

	printf("修改成功\n");
	return ;
}


void update_student_info(linknode_t *temp)
{
	int num = -1;
	display_update_info();

loop:
	printf("请输入你要修改的学生信息编号:");
	scanf("%d",&num);

	//清除缓冲区的数据
	while(getchar() != '\n');
	
	if(!(num >= 1 && num <= 6))
	{
		printf("信息输入错误,请重试!\n");	
		goto loop;
	}

    user_change_data(temp,num);

}


//更新学生信息
void update_student(linknode_t *head)
{
	linknode_t *p = head;
	int id = 0,num = 0;
	printf("请输入要修改的学生编号 : ");
	scanf("%d",&id);

	while(p->next != NULL)
	{
		if(p->next->data.id == id)
		{
			update_student_info(p->next);
			break;
		}	
		p = p->next;	
	}

	if(p->next == NULL)
	{
		printf("---------------------------------------------------------------\n");
		printf("编号输入错误!\n");	
		printf("---------------------------------------------------------------\n");
	}
	
	return ; 
}

void delete_student(linknode_t *head)
{
	int ret = 0;
	int id = 0;
loop:
	printf("请输入要删除的学生编号 : ");
	scanf("%d",&id);

	ret = delete_data_linklist(head,id);

	if(ret == -1)
	{
		printf("数据数据为空,删除无效\n");	
	}else if(ret == -2){
		printf("数据数据不存在,用重新输入\n");	
		goto loop;
	}else{
		printf("删除id = %d学生信息成功\n",id);	

	}

	return ;
}



