#ifndef __CALENDAR_H__
#define __CALENDAR_H__

#include <stdio.h>

#define LE_YEAR 1

extern int isleap(int y);
extern int max_day(int y,int m);
extern int total_day(int y,int m,int d);
extern int weekday(int y,int m,int d);
extern void display_week(int y,int m,int d);
extern void display_month(int y,int m,int d);

#endif
