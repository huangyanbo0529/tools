#include "calendar.h"

int isleap(int y)
{
	if((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0))
	{
		return 1; //闰年	
	}else{
		return 0;//平年	
	}
}

int max_day(int y,int m)
{
	int month[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
	int ret = 0;

	ret = isleap(y);

	if(ret == LE_YEAR)
	{
		month[1] = 29;	
	}

	return month[m - 1];
}


//计算：输入的year，month，day是该年的第多少天？
//2015.1.1 ～ 2015.3.4   63
int total_day(int y,int m,int d)
{
	int sum = 0;
	int i = 0;

	for(i = 1;i < m;i++)
	{
		sum = sum + max_day(y,i);	
	}

	sum = sum + d;
	return sum;
}

int weekday(int y,int m,int d)
{
	int count = 0;

	if(m == 1 || m == 2)
	{
		m = m + 12;
		y = y - 1;
	}

	count = (d + 2*m + 3*(m+1) / 5 + y + y / 4 - y / 100 + y / 400 + 1)%7;
	
	return count;
}

void display_week(int y,int m,int d)
{
	int count = 0;

	//计算星期的函数	
	count = weekday(y,m,d);


	switch(count)
	{
		case 0:
			printf("%d-%d-%d is Sunday\n",y,m,d);
			break;
		case 1:
			printf("%d-%d-%d is Monday\n",y,m,d);
			break;
		case 2:
			printf("%d-%d-%d is Tuesday\n",y,m,d);
			break;
		case 3:
			printf("%d-%d-%d is Wednesday\n",y,m,d);
			break;
		case 4:
			printf("%d-%d-%d is Thursday\n",y,m,d);
			break;
		case 5:
			printf("%d-%d-%d is Faiday\n",y,m,d);
			break;
		case 6:
			printf("%d-%d-%d is Saturday\n",y,m,d);
			break;
	}
}

void display_month(int y,int m,int d)
{
	int w;
	int i = 0;
	int max;

	//1.获得每个月的1日的星期数
	
	w = weekday(y,m,1);

	printf("\n\t\t%d year %d month\n",y,m);
	printf("SUN\tMON\tTUE\tWED\tTHU\tFRI\tSAT\n");

	for(i = 0;i < w;i++)
	{
		printf("\t");	
	}


	max = max_day(y,m);

	for(i = 1;i <= max;i++)
	{
		printf("%d\t",i);	
		if((w + i) % 7 == 0)
		{
			printf("\n");	
		}
	}

	printf("\n");

}

